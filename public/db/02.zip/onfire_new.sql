-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2023 at 02:47 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `onfire_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `parent_id`, `photo`, `photo_thum_1`, `icon`, `is_active`, `postion`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, NULL, 'images/category/1/1696769012_38xGZfq7uTYwlig_.webp', 'images/category/1/1696769013_qlxHOchJt6k2vY8_.webp', NULL, 1, 0, '2023-10-08 07:39:59', '2023-10-08 11:43:33', NULL),
(2, NULL, 'images/category/2/1696769046_t4wxe39vomlh0DE_.webp', 'images/category/2/1696769046_ppwi3Y19ZvzkaCM_.webp', NULL, 1, 0, '2023-10-08 07:40:10', '2023-10-08 11:44:06', NULL),
(3, NULL, 'images/category/3/1696769062_CG3Swekd9EA8JE1_.webp', 'images/category/3/1696769062_ATf46UjA6Jtm5fE_.webp', NULL, 1, 0, '2023-10-08 07:40:30', '2023-10-08 11:44:22', NULL),
(4, NULL, 'images/category/4/1696769080_I2PTFsLPbyZMNuJ_.webp', 'images/category/4/1696769080_CablI9eIEAjbDQR_.webp', NULL, 1, 0, '2023-10-08 07:40:42', '2023-10-08 11:44:40', NULL),
(5, NULL, 'images/category/5/1696769103_44TWzD4W0MtWICH_.webp', 'images/category/5/1696769103_08oOhMiMwumIzyJ_.webp', NULL, 1, 0, '2023-10-08 07:40:49', '2023-10-08 11:45:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `category_product`
--

CREATE TABLE `category_product` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_product`
--

INSERT INTO `category_product` (`id`, `category_id`, `product_id`) VALUES
(4, 1, 2),
(5, 2, 3),
(6, 4, 3),
(7, 5, 3);

-- --------------------------------------------------------

--
-- Table structure for table `category_translations`
--

CREATE TABLE `category_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `category_translations`
--

INSERT INTO `category_translations` (`id`, `category_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(1, 1, 'ar', 'برجر', 'برجر', NULL, NULL, NULL),
(2, 2, 'ar', 'سندوتشات-الفراخ', 'سندوتشات الفراخ', NULL, NULL, NULL),
(3, 3, 'ar', 'فرايد-تشيكن', 'فرايد تشيكن', NULL, NULL, NULL),
(4, 4, 'ar', 'مقبلات', 'مقبلات', NULL, NULL, NULL),
(5, 5, 'ar', 'العروض', 'العروض', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_def_photos`
--

CREATE TABLE `config_def_photos` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_def_photos`
--

INSERT INTO `config_def_photos` (`id`, `cat_id`, `photo`, `photo_thum_1`, `photo_thum_2`, `postion`, `created_at`, `updated_at`) VALUES
(1, 'light-logo', 'images/def-photo/light-logo-AJG4FyEGq8.webp', NULL, NULL, 2, '2023-09-03 15:03:13', '2023-09-03 15:04:25'),
(2, 'dark-logo', 'images/def-photo/dark-logo-yHavtqPGm6.webp', NULL, NULL, 1, '2023-09-03 15:04:17', '2023-09-03 15:04:25'),
(3, 'about-1', 'images/def-photo/about-1-yn7io2tGJe.webp', NULL, NULL, 0, '2023-09-04 14:21:50', '2023-09-04 14:21:50'),
(4, 'about-2', 'images/def-photo/about-2-hRbvFjEYBB.webp', NULL, NULL, 0, '2023-09-04 14:22:23', '2023-09-08 14:41:31'),
(5, 'faq-icon', 'images/def-photo/faq-icon-Trcw3x3A7W.webp', 'images/def-photo/faq-icon-Ns5XjqT77R.webp', NULL, 0, '2023-09-04 18:17:24', '2023-09-04 18:24:42'),
(6, 'contact-from', 'images/def-photo/contact-from-taOS5rT9SI.webp', NULL, NULL, 0, '2023-09-06 19:37:35', '2023-09-06 19:37:35'),
(7, 'blog', 'images/def-photo/blog-CDdCixPmfn.webp', 'images/def-photo/blog-EE6OS73peP.webp', NULL, 0, '2023-09-07 11:29:31', '2023-09-07 11:32:49'),
(8, 'categorie', 'images/def-photo/categorie-9HziJATU67.webp', NULL, NULL, 0, '2023-09-07 16:54:20', '2023-09-07 17:40:43'),
(9, 'banner_1', 'images/def-photo/banner-1-VLqPKFQFUX.webp', NULL, NULL, 0, '2023-09-11 09:43:54', '2023-09-11 10:21:22'),
(10, 'whatsapp', 'images/def-photo/whatsapp-rJdy3I8bAn.webp', NULL, NULL, 0, '2023-09-11 10:15:56', '2023-09-11 10:15:56'),
(11, 'direction', 'images/def-photo/direction-HxHKFfw5Qy.webp', NULL, NULL, 0, '2023-09-11 10:36:35', '2023-09-11 10:39:29'),
(12, 'shop_banner', 'images/def-photo/shop-banner-gkb95aTjI6.webp', NULL, NULL, 0, '2023-09-11 10:41:58', '2023-09-11 11:22:05'),
(13, 'offer-1', 'images/def-photo/offer-1-ZEhHpqSHCu.webp', NULL, NULL, 0, '2023-09-11 21:24:36', '2023-09-11 21:28:49'),
(14, 'form_login', 'images/def-photo/cust-login-5vzy5IZjUZ.webp', NULL, NULL, 0, '2023-09-29 00:45:03', '2023-09-29 03:16:32'),
(15, 'form_sign_up', 'images/def-photo/form-sign-up-AlQFSq2P80.webp', NULL, NULL, 0, '2023-09-29 03:17:07', '2023-09-29 03:33:50');

-- --------------------------------------------------------

--
-- Table structure for table `config_settings`
--

CREATE TABLE `config_settings` (
  `id` int(10) UNSIGNED NOT NULL,
  `web_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web_status` int(11) NOT NULL DEFAULT 1,
  `logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `favicon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_num` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_text` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `def_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `google_api` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `download_app` int(11) NOT NULL DEFAULT 0,
  `top_offer` int(11) NOT NULL DEFAULT 0,
  `apple` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `android` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `windows` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_group` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `telegram_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `whatsapp_send_to` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_settings`
--

INSERT INTO `config_settings` (`id`, `web_url`, `web_status`, `logo`, `favicon`, `phone_num`, `whatsapp_num`, `phone_text`, `whatsapp_text`, `facebook`, `youtube`, `twitter`, `instagram`, `linkedin`, `def_url`, `google_api`, `download_app`, `top_offer`, `apple`, `android`, `windows`, `telegram_key`, `telegram_group`, `telegram_phone`, `whatsapp_key`, `whatsapp_send_to`, `notes`, `created_at`, `updated_at`) VALUES
(1, '#', 1, '', '', '01006180117', '201006180117', '0100-6180-117', '0100-6180-117', 'https://www.facebook.com/Etman.Group', 'https://www.youtube.com/channel/UC8GkiBf6L9bogsUtx0PEgTg', '#', 'https://www.instagram.com/etmangroup.eg/', 'https://www.linkedin.com/company/etman-group/', 'https://etman-group.com', 'AIzaSyDWuKOMM4hm_uBnQjqQufaLlHSN2QS_4Qo', 1, 1, 'https://www.apple.com/store', 'https://play.google.com/store/apps?hl=en&amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;amp;gl=US', 'https://www.microsoft.com/en-eg/store/', '6313317483:AAEooBTEFel1ej1uaDpXcZzCrbX_ID3aYEw', '-1001989217795', '200119925', '8592e88ef28ba32bd5e5b59c11a59f864a898e53b94cbacb04a87dc1f0c377c1887491212d364739', '01010881921', '8592e88ef28ba32bd5e5b59c11a59f864a898e53b94cbacb04a87dc1f0c377c1887491212d364739\r\n01010881921\r\n\r\n6313317483:AAEooBTEFel1ej1uaDpXcZzCrbX_ID3aYEw\r\n-1001989217795\r\n200119925\r\n\r\nsss', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `config_setting_translations`
--

CREATE TABLE `config_setting_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `setting_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `closed_mass` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `offer` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_setting_translations`
--

INSERT INTO `config_setting_translations` (`id`, `setting_id`, `locale`, `name`, `g_title`, `g_des`, `closed_mass`, `offer`) VALUES
(1, 1, 'ar', 'عتمان جروب', 'عنوان الصفحة يكتب هنا', 'وصف الصفحة يكتب هنا', 'زوار موقعنا الكرام ... تلبية لرغبتكم الكريمة فى تطوير الموقع \r\nوليرتقى للمستوى العالمى فى تقديم كل ما يهمكم \r\nنحن بصدد تطوير الموقع كليا ليتناسب معكم\r\nادارة الموقع', 'شحن مجانى للطلبات اكثر من 2500 جنية داخل الاسكندرية'),
(2, 1, 'en', 'Etman Group', 'The title of the site is written here', 'The description of the site is written here', 'Dear visitors ... In response to your generous desire to develop the site ... and to rise to the international level in providing everything that interests you ... \r\nWe are in the process of developing the website completely to suit you ..\r\nSite Administration', 'Free Ground Shipping Over  2500 LE');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filters`
--

CREATE TABLE `config_upload_filters` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `convert_state` int(11) NOT NULL DEFAULT 1,
  `quality_val` int(11) NOT NULL DEFAULT 85,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '#ffffff',
  `greyscale` int(11) NOT NULL DEFAULT 0,
  `flip_state` int(11) NOT NULL DEFAULT 0,
  `flip_v` int(11) NOT NULL DEFAULT 0,
  `blur` int(11) NOT NULL DEFAULT 0,
  `blur_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `pixelate` int(11) NOT NULL DEFAULT 0,
  `pixelate_size` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '5',
  `text_state` int(11) NOT NULL DEFAULT 0,
  `text_print` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_size` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `font_opacity` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `text_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_state` int(11) NOT NULL DEFAULT 0,
  `watermark_img` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `watermark_position` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filters`
--

INSERT INTO `config_upload_filters` (`id`, `name`, `type`, `convert_state`, `quality_val`, `new_w`, `new_h`, `canvas_back`, `greyscale`, `flip_state`, `flip_v`, `blur`, `blur_size`, `pixelate`, `pixelate_size`, `text_state`, `text_print`, `font_size`, `font_path`, `font_color`, `font_opacity`, `text_position`, `watermark_state`, `watermark_img`, `watermark_position`, `state`, `created_at`, `updated_at`) VALUES
(1, 'NoEdit', 1, 1, 85, 100, 100, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(2, 'DefPhoto', 4, 1, 85, 800, 420, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(3, 'FavIcon', 4, 1, 85, 40, 40, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(4, 'صورة المجموعة', 4, 1, 85, 700, 700, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-18 05:33:44'),
(5, 'PhotoGallery', 4, 1, 85, 1024, 768, '#ffffff', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-06 21:57:01', '2023-09-06 21:57:01'),
(6, 'اخر الاخبار', 4, 1, 85, 450, 237, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-07 11:27:22', '2023-09-07 11:27:22'),
(7, 'بانر', 4, 1, 85, 840, 410, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-11 09:36:55', '2023-09-11 10:03:12'),
(8, 'صورة المنتج', 5, 1, 85, 1000, 1000, '#FFFFFF', 0, 0, 0, 0, '0', 0, '5', 0, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, '2023-09-11 17:01:05', '2023-09-11 17:01:39');

-- --------------------------------------------------------

--
-- Table structure for table `config_upload_filter_sizes`
--

CREATE TABLE `config_upload_filter_sizes` (
  `id` int(10) UNSIGNED NOT NULL,
  `filter_id` int(10) UNSIGNED NOT NULL,
  `type` int(11) NOT NULL DEFAULT 1,
  `new_w` int(11) NOT NULL,
  `new_h` int(11) NOT NULL,
  `canvas_back` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `get_more_option` int(11) NOT NULL DEFAULT 0,
  `get_add_text` int(11) NOT NULL DEFAULT 0,
  `get_watermark` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_upload_filter_sizes`
--

INSERT INTO `config_upload_filter_sizes` (`id`, `filter_id`, `type`, `new_w`, `new_h`, `canvas_back`, `get_more_option`, `get_add_text`, `get_watermark`) VALUES
(1, 2, 4, 500, 335, NULL, 0, 0, 0),
(2, 4, 4, 350, 350, '#FFFFFF', 0, 0, 0),
(3, 5, 4, 800, 600, '#ffffff', 0, 0, 0),
(4, 5, 4, 320, 240, '#ffffff', 0, 0, 0),
(5, 6, 4, 900, 473, '#FFFFFF', 0, 0, 0),
(6, 7, 4, 420, 205, '#FFFFFF', 0, 0, 0),
(7, 8, 5, 350, 350, '#FFFFFF', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacies`
--

CREATE TABLE `config_web_privacies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `postion` int(11) NOT NULL DEFAULT 0,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacies`
--

INSERT INTO `config_web_privacies` (`id`, `name`, `postion`, `is_active`, `created_at`, `updated_at`) VALUES
(2, 'شروط وسياسة الخصوصية', 2, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(3, 'جمع المعلومات واستخدامها', 3, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(4, 'أنواع البيانات المجمعة', 4, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(5, 'بيانات الاستخدام', 5, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(6, 'تتبع و ملفات تعريف الارتباط', 6, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(7, 'استخدام البيانات', 7, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(8, 'نقل البيانات', 8, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(9, 'الكشف عن البيانات', 9, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(10, 'أمن البيانات', 10, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(11, 'مقدمي الخدمة', 11, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(12, 'تحليلات', 12, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(13, 'روابط لمواقع أخرى', 13, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(14, 'خصوصية الأطفال', 14, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(15, 'تغييرات سياسة الخصوصية', 15, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57'),
(16, 'اتصل بنا', 16, 1, '2023-08-24 12:42:57', '2023-08-24 12:42:57');

-- --------------------------------------------------------

--
-- Table structure for table `config_web_privacy_translations`
--

CREATE TABLE `config_web_privacy_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `privacy_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `h2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lists` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `config_web_privacy_translations`
--

INSERT INTO `config_web_privacy_translations` (`id`, `privacy_id`, `locale`, `h1`, `h2`, `des`, `lists`) VALUES
(3, 2, 'ar', 'شروط وسياسة الخصوصية', '', 'تقوم شركة [CompanyName] (\"نحن\" أو \"نحن\" أو \"موقعنا\") بتشغيل [WebSiteName]  (\"الموقع الالكترونى\").\r\nتُعرفك هذه الصفحة بسياساتنا المتعلقة بجمع البيانات الشخصية واستخدامها والكشف عنها عند استخدامك للخدمة والأختيارات المرتبطة بهذه البيانات. \r\nسياسة الخصوصية لشركة [CompanyName]\r\nنستخدم بياناتك لتوفير الخدمة وتحسينها. باستخدام الخدمة، فإنك توافق على جمع واستخدام المعلومات وفقًا لهذه السياسة. ما لم يتم تحديد خلاف ذلك في سياسة الخصوصية، فإن المصطلحات المستخدمة في سياسة الخصوصية لها نفس المعاني كما في الشروط والأحكام الخاصة بنا، والتي يمكن الوصول إليها من [WebSiteName]', ''),
(4, 2, 'en', 'Privacy Policy', '', ' [CompanyName] (\"us\", \"we\", or \"our\") operates the [WebSiteName] website (the \"Service\").\r\nThis page informs you of our policies regarding the collection, use, and disclosure of personal data when you use our Service and the choices you have associated with that data. Our Privacy Policy for [CompanyName]\r\nWe use your data to provide and improve the Service. By using the Service, you agree to the collection and use of information in accordance with this policy. Unless otherwise defined in this Privacy Policy, terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, accessible from  [WebSiteName]', ''),
(5, 3, 'ar', 'جمع المعلومات واستخدامها', '', 'نقوم بتجميع أنواع مختلفة من المعلومات لأغراض متنوعة لتوفير وتحسين خدماتنا لك.', ''),
(6, 3, 'en', 'Information Collection And Use', '', 'We collect several different types of information for various purposes to provide and improve our Service to you.', ''),
(7, 4, 'ar', 'أنواع البيانات المجمعة', 'بيانات شخصية', 'أثناء استخدام خدماتنا ، قد نطلب منك تزويدنا بمعلومات تعريف شخصية معينة يمكن استخدامها للاتصال أو التعرف عليك (&quot;البيانات الشخصية&quot;). قد تتضمن معلومات \r\nالتعريف الشخصية ، على سبيل المثال لا الحصر ، ما يلي:', 'عنوان بريد الكتروني\r\nالاسم الأول واسم العائلة\r\nرقم الهاتف\r\nالعنوان ، الولاية ، المقاطعة ، الرمز البريدي / المدينة ، المدينة\r\nملفات تعريف الارتباط وبيانات الاستخدام'),
(8, 4, 'en', 'Types of Data Collected', 'Personal Data', 'While using our Service, we may ask you to provide us with certain personally identifiable information that can be used to contact or identify you (&quot;Personal Data&quot;). Personally identifiable information may include, but is not limited to :', 'Email address\r\nFirst name and last name\r\nPhone number\r\nAddress, State, Province, ZIP/Postal code, City\r\nCookies and Usage Data'),
(9, 5, 'ar', 'بيانات الاستخدام', '', 'يجوز لنا أيضًا جمع المعلومات حول كيفية الوصول إلى الخدمة واستخدامها (&quot;بيانات الاستخدام&quot;). قد تتضمن بيانات الاستخدام هذه معلومات مثل عنوان بروتوكول الإنترنت الخاص بجهاز الكمبيوتر (مثل عنوان IP) ، ونوع المتصفح، وإصدار المتصفح، وصفحات الخدمة التي تزورها، ووقت وتاريخ زيارتك، والوقت الذي يقضيه في تلك الصفحات، ومعرفات الجهاز وغيرها من البيانات التشخيصية.', ''),
(10, 5, 'en', 'Usage Data', '', 'We may also collect information how the Service is accessed and used (&quot;Usage Data&quot;). This Usage Data may include information such as your computer\'s Internet Protocol address (e.g. IP address), browser type, browser version, the pages of our Service that you visit, the time and date of your visit, the time spent on those pages, unique device identifiers and other diagnostic data.', ''),
(11, 6, 'ar', 'تتبع و ملفات تعريف الارتباط', '', 'نحن نستخدم ملفات تعريف الارتباط وتقنيات التتبع المماثلة لتتبع النشاط على الخدمة لدينا مع الاحتفاظ بمعلومات معينة.\r\nملفات تعريف الارتباط عبارة عن ملفات تحتوي على كمية صغيرة من البيانات التي قد تتضمن معرفًا فريدًا مجهول الهوية. يتم إرسال ملفات تعريف الارتباط إلى متصفحك من موقع الويب وتخزينها على جهازك. تقنيات التتبع المستخدمة هي منارات وعلامات ونصوص لجمع المعلومات وتتبعها ولتحسين خدمتنا وتحليلها.\r\nيمكنك إرشاد المتصفح الخاص بك لرفض جميع ملفات تعريف الارتباط أو للإشارة إلى إرسال ملف تعريف الارتباط. ومع ذلك، إذا كنت لا تقبل ملفات تعريف الارتباط، فقد لا تتمكن من استخدام بعض أجزاء من خدمتنا.\r\n\r\nأمثلة على ملفات تعريف الارتباط التي نستخدمها:', 'نحن نستخدم ملفات تعريف الارتباط الخاصة بالجلسات لتشغيل الخدمة الخاصة بنا.\r\nنحن نستخدم ملفات تعريف الارتباط التفضيلية لتذكر تفضيلاتك والإعدادات المختلفة.\r\nنحن نستخدم ملفات تعريف الارتباط للأمان لأغراض أمنية.'),
(12, 6, 'en', 'Tracking &amp; Cookies Data', '', 'We use cookies and similar tracking technologies to track the activity on our Service and hold certain information.\r\nCookies are files with small amount of data which may include an anonymous unique identifier. Cookies are sent to your browser from a website and stored on your device. Tracking technologies also used are beacons, tags, and scripts to collect and track information and to improve and analyze our Service.\r\nYou can instruct your browser to refuse all cookies or to indicate when a cookie is being sent. However, if you do not accept cookies, you may not be able to use some portions of our Service.\r\n\r\nExamples of Cookies we use:', 'Session Cookies. We use Session Cookies to operate our Service.\r\nPreference Cookies. We use Preference Cookies to remember your preferences and various settings.\r\nSecurity Cookies. We use Security Cookies for security purposes.'),
(13, 7, 'ar', 'استخدام البيانات', '', 'تستخدم [CompanyName] البيانات التي تم جمعها لأغراض مختلفة :', 'لإعلامك عن تغييرات لخدمتنا.\r\nللسماح لك بالمشاركة في الميزات التفاعلية في خدمتنا عندما تختار القيام بذلك.\r\nلتوفير رعاية العملاء والدعم.\r\nلتقديم تحليل أو معلومات قيمة حتى نتمكن من تحسين الخدمة.\r\nلمراقبة استخدام الخدمة.\r\nللكشف عن المشكلات الفنية ومنعها ومعالجتها.'),
(14, 7, 'en', 'Use of Data', '', '[CompanyName] uses the collected data for various purposes:', 'To provide and maintain the Service.\r\nTo notify you about changes to our Service.\r\nTo allow you to participate in interactive features of our Service when you choose to do so.\r\nTo provide customer care and support.\r\nTo provide analysis or valuable information so that we can improve the Service.\r\nTo monitor the usage of the Service.\r\nTo detect, prevent and address technical issues.'),
(15, 8, 'ar', 'نقل البيانات', '', 'قد يتم نقل معلوماتك - بما في ذلك البيانات الشخصية - إلى أجهزة الكمبيوتر الموجودة خارج الولاية أو المقاطعة أو الدولة أو الولاية الحكومية الأخرى التي قد تختلف فيها قوانين حماية البيانات عن تلك الخاصة باختصاصك القضائي.\r\nإذا كنت متواجدًا خارج مصر واخترت تقديم معلومات لنا، يرجى ملاحظة أننا نقوم بنقل البيانات، بما في ذلك البيانات الشخصية، إلى مصر ومعالجتها هناك.\r\nإن موافقتك على سياسة الخصوصية هذه والتي يتبعها تقديمك لهذه المعلومات تمثل موافقتك على هذا النقل \r\nسوف تتخذ [CompanyName] جميع الخطوات الضرورية بشكل معقول لضمان التعامل مع بياناتك بشكل آمن ووفقًا لسياسة الخصوصية هذه ولن يتم نقل بياناتك الشخصية إلى منظمة أو دولة ما لم تكن هناك ضوابط كافية في مكان بما في ذلك أمن البيانات الخاصة بك وغيرها من المعلومات الشخصية.', ''),
(16, 8, 'en', 'Transfer Of Data', '', 'Your information, including Personal Data, may be transferred to — and maintained on — computers located outside of your state, province, country or other governmental jurisdiction where the data protection laws may differ than those from your jurisdiction.\r\nIf you are located outside Egypt and choose to provide information to us, please note that we transfer the data, including Personal Data, to Egypt and process it there.\r\nYour consent to this Privacy Policy followed by your submission of such information represents your agreement to that transfer.\r\n[CompanyName] will take all steps reasonably necessary to ensure that your data is treated securely and in accordance with this Privacy Policy and no transfer of your Personal Data will take place to an organization or a country unless there are adequate controls in place including the security of your data and other personal information.', ''),
(17, 9, 'ar', 'الكشف عن البيانات', 'المتطلبات القانونية', 'يحق لـ [CompanyName] الإفصاح عن بياناتك الشخصية بحسن نية من أن هذا الإجراء ضروري من أجل:', 'للامتثال لالتزام قانوني\r\nلحماية والدفاع عن حقوق أو ملكية [CompanyName]\r\nلمنع أو التحقيق في أي مخالفات محتملة تتعلق بالخدمة.\r\nلحماية السلامة الشخصية لمستخدمي الخدمة أو الجمهور.\r\nللحماية من المسؤولية القانونية.'),
(18, 9, 'en', 'Disclosure Of Data', 'Legal Requirements', '[CompanyName] may disclose your Personal Data in the good faith belief that such action is necessary to:', 'To comply with a legal obligation.\r\nTo protect and defend the rights or property of [CompanyName]\r\nTo prevent or investigate possible wrongdoing in connection with the Service.\r\nTo protect the personal safety of users of the Service or the public.\r\nTo protect against legal liability.'),
(19, 10, 'ar', 'أمن البيانات', '', 'أمان بياناتك مهم بالنسبة لنا، ولكن تذكر أنه لا توجد طريقة للإرسال عبر الإنترنت، أو طريقة التخزين الإلكترونية آمنة ١٠٠٪. بينما نسعى جاهدين لاستخدام وسائل مقبولة تجاريًا لحماية بياناتك الشخصية، لا يمكننا ضمان أمانها المطلق.', ''),
(20, 10, 'en', 'Security Of Data', '', 'The security of your data is important to us, but remember that no method of transmission over the Internet, or method of electronic storage is 100% secure. While we strive to use commercially acceptable means to protect your Personal Data, we cannot guarantee its absolute security.', ''),
(21, 11, 'ar', 'مقدمي الخدمة', '', 'يجوز لنا أن نوظف شركات وأفراد من أطراف ثالثة لتسهيل خدمتنا (&quot;مزودي الخدمة&quot;)، أو تقديم الخدمة نيابة عنا، لأداء الخدمات المتعلقة بالخدمة أو لمساعدتنا في تحليل كيفية استخدام خدمتنا.\r\nهذه الأطراف الثالثة لديها حق الوصول إلى بياناتك الشخصية فقط لأداء هذه المهام نيابة عنا وتكون ملزمة بعدم الكشف عنها أو استخدامها لأي غرض آخر.', ''),
(22, 11, 'en', 'Service Providers', '', 'We may employ third party companies and individuals to facilitate our Service (&quot;Service Providers&quot;), to provide the Service on our behalf, to perform Service-related services or to assist us in analyzing how our Service is used.\r\nThese third parties have access to your Personal Data only to perform these tasks on our behalf and are obligated not to disclose or use it for any other purpose.', ''),
(23, 12, 'ar', 'تحليلات', '', 'قد نستخدم مزودي خدمة من جهات خارجية لمراقبة وتحليل استخدام خدماتنا.', ''),
(24, 12, 'en', 'Analytics', '', 'We may use third-party Service Providers to monitor and analyze the use of our Service.', ''),
(25, 13, 'ar', 'روابط لمواقع أخرى', '', 'قد تحتوي خدمتنا على روابط إلى مواقع أخرى لا يتم تشغيلها من قبلنا. إذا نقرت على رابط جهة خارجية، فسيتم توجيهك إلى موقع الطرف الثالث هذا. ننصحك بشدة بمراجعة سياسة الخصوصية لكل موقع تزوره.\r\n\r\nليس لدينا أي سيطرة ولا نتحمل أي مسؤولية عن المحتوى أو سياسات الخصوصية أو الممارسات الخاصة بأي مواقع أو خدمات خاصة بطرف ثالث.', ''),
(26, 13, 'en', 'Links To Other Sites', '', 'Our Service may contain links to other sites that are not operated by us. If you click on a third party link, you will be directed to that third party\'s site. We strongly advise you to review the Privacy Policy of every site you visit.\r\n\r\nWe have no control over and assume no responsibility for the content, privacy policies or practices of any third party sites or services.', ''),
(27, 14, 'ar', 'خصوصية الأطفال', '', 'لا تتناول خدمتنا أي شخص دون سن ١٨ عامًا (&quot;الأطفال&quot;).\r\nنحن لا نجمع معلومات التعريف الشخصية من أي شخص دون سن ١٨ عامًا. إذا كنت أحد الوالدين أو الوصي وكنت على علم بأن أطفالك قد زودونا ببيانات شخصية، يرجى الاتصال بنا. إذا علمنا أننا جمعنا بيانات شخصية من الأطفال دون التحقق من موافقة الوالدين، فإننا نتخذ خطوات لإزالة تلك المعلومات من خوادمنا.', ''),
(28, 14, 'en', 'Children\'s Privacy', '', 'Our Service does not address anyone under the age of 18 (&quot;Children&quot;).\r\nWe do not knowingly collect personally identifiable information from anyone under the age of 18. If you are a parent or guardian and you are aware that your Children has provided us with Personal Data, please contact us. If we become aware that we have collected Personal Data from children without verification of parental consent, we take steps to remove that information from our servers.', ''),
(29, 15, 'ar', 'تغييرات سياسة الخصوصية', '', 'يجوز لنا تحديث سياسة الخصوصية الخاصة بنا من وقت لآخر. سنعلمك بأي تغييرات عن طريق نشر سياسة الخصوصية الجديدة على هذه الصفحة.\r\nسنخبرك عبر البريد الإلكتروني و/ أو بإشعار بارز في خدمتنا، قبل أن يصبح التغيير ساريًا وتحديث &quot;تاريخ الفعالية&quot; في أعلى سياسة الخصوصية هذه.\r\nننصحك بمراجعة سياسة الخصوصية هذه بشكل دوري لأية تغييرات. تسري التغييرات التي تطرأ على سياسة الخصوصية هذه عند نشرها على هذه الصفحة.', ''),
(30, 15, 'en', 'Changes To This Privacy Policy', '', 'We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page.\r\n\r\nWe will let you know via email and/or a prominent notice on our Service, prior to the change becoming effective and update the &quot;effective date&quot; at the top of this Privacy Policy.\r\n\r\nYou are advised to review this Privacy Policy periodically for any changes. Changes to this Privacy Policy are effective when they are posted on this page.', ''),
(31, 16, 'ar', 'اتصل بنا', '', 'إذا كان لديك أي أسئلة حول سياسة الخصوصية هذه، يرجى الاتصال بنا:', 'البريد الإلكتروني : info@etman-group.com'),
(32, 16, 'en', 'Contact Us', '', 'If you have any questions about this Privacy Policy, please contact us:', 'Email:info@etman-group.com');

-- --------------------------------------------------------

--
-- Table structure for table `contact_us_forms`
--

CREATE TABLE `contact_us_forms` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `data_cities`
--

CREATE TABLE `data_cities` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `data_cities`
--

INSERT INTO `data_cities` (`id`, `name`, `name_en`, `is_active`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'القاهرة', 'Cairo', 1, NULL, NULL, NULL),
(2, 'القاهرة الجديدة', 'New Cairo', 1, NULL, NULL, NULL),
(3, 'الاسكندرية', 'Alexandria', 1, NULL, NULL, NULL),
(4, 'الاسماعيلية', 'Ismailia', 1, NULL, NULL, NULL),
(5, 'اسوان', 'Aswan', 1, NULL, NULL, NULL),
(6, 'اسيوط', 'Asyut', 1, NULL, NULL, NULL),
(7, 'الاقصر', 'Luxor', 1, NULL, NULL, NULL),
(8, 'البحر الاحمر', 'Red Sea', 1, NULL, NULL, NULL),
(9, 'البحيرة', 'Beheira ', 1, NULL, NULL, NULL),
(10, 'بني سويف', 'Beni Suef', 1, NULL, NULL, NULL),
(11, 'بورسعيد', 'Port Said', 1, NULL, NULL, NULL),
(12, 'جنوب سيناء', 'South Sinai', 1, NULL, NULL, NULL),
(13, 'الجيزة', 'Giza', 1, NULL, NULL, NULL),
(14, 'الدقهلية', 'Dakahlia', 1, NULL, NULL, NULL),
(15, 'دمياط', 'Damietta', 1, NULL, NULL, NULL),
(16, 'سوهاج', 'Sohag', 1, NULL, NULL, NULL),
(17, 'السويس', 'Suez', 1, NULL, NULL, NULL),
(18, 'الشرقية', 'Sharqia', 1, NULL, NULL, NULL),
(19, 'شمال سيناء', 'North Sinai', 1, NULL, NULL, NULL),
(20, 'الغربية', 'Gharbia', 1, NULL, NULL, NULL),
(21, 'الفيوم', 'Faiyum', 1, NULL, NULL, NULL),
(22, 'القليوبية', 'Qalyubia', 1, NULL, NULL, NULL),
(23, 'قنا', 'Qena', 1, NULL, NULL, NULL),
(24, 'كفر الشيخ', 'Kafr El Sheikh', 1, NULL, NULL, NULL),
(25, 'مطروح', 'Matruh', 1, NULL, NULL, NULL),
(26, 'المنوفية', 'Monufia', 1, NULL, NULL, NULL),
(27, 'المنيا', 'Minya', 1, NULL, NULL, NULL),
(28, 'الوادى الجديد', 'New Valley', 1, NULL, NULL, NULL),
(29, 'غير محدد', 'undefined', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(133, '2014_10_12_000000_create_users_table', 1),
(134, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(135, '2014_10_12_100000_create_password_resets_table', 1),
(136, '2019_08_19_000000_create_failed_jobs_table', 1),
(137, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(138, '2023_06_24_105531_create_settings_table', 1),
(139, '2023_06_24_144232_create_setting_translations_table', 1),
(140, '2023_06_29_193744_create_def_photos_table', 1),
(141, '2023_06_29_235416_create_upload_filters_table', 1),
(142, '2023_07_03_115945_create_upload_filter_sizes_table', 1),
(143, '2023_07_12_171931_create_permission_tables', 1),
(144, '2023_07_14_112208_add_names_roles_table', 1),
(145, '2023_07_14_115125_add_names_permissions_table', 1),
(146, '2023_07_16_155230_create_categories_table', 1),
(147, '2023_07_16_155651_create_category_translations_table', 1),
(148, '2023_08_23_130011_create_products_table', 1),
(149, '2023_08_23_130057_create_product_translations_table', 1),
(150, '2023_08_23_172346_create_product_photos_table', 1),
(151, '2023_08_24_145512_create_web_privacies_table', 1),
(152, '2023_08_24_145811_create_web_privacy_translations_table', 1),
(153, '2023_08_29_091745_create_pages_table', 1),
(154, '2023_08_29_091812_create_page_translations_table', 1),
(155, '2023_09_17_172739_create_product_category_table', 1),
(156, '2023_09_23_143553_create_shoppingcart_table', 1),
(157, '2023_09_28_141144_create_users_customers_table', 1),
(158, '2023_09_29_143600_create_data_cities_table', 1),
(159, '2023_09_29_173742_create_users_customers_addresses_table', 1),
(160, '2023_09_30_131508_create_shopping_order_addresses_table', 1),
(161, '2023_09_30_131534_create_shopping_orders_table', 1),
(162, '2023_09_30_131551_create_shopping_order_products_table', 1),
(163, '2023_10_04_055847_create_news_letters_table', 1),
(164, '2023_10_05_123803_create_shopping_order_logs_table', 1),
(165, '2023_10_07_163342_create_contact_us_forms_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

CREATE TABLE `model_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

CREATE TABLE `model_has_roles` (
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 1),
(2, 'App\\Models\\User', 2),
(3, 'App\\Models\\User', 3),
(4, 'App\\Models\\User', 3),
(4, 'App\\Models\\User', 4),
(7, 'App\\Models\\User', 3),
(7, 'App\\Models\\User', 4);

-- --------------------------------------------------------

--
-- Table structure for table `news_letters`
--

CREATE TABLE `news_letters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `id` int(10) UNSIGNED NOT NULL,
  `cat_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `view_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `banner_id` int(11) DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `menu_main` tinyint(1) NOT NULL DEFAULT 0,
  `menu_footer` tinyint(1) NOT NULL DEFAULT 0,
  `postion` int(11) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `cat_id`, `view_name`, `banner_id`, `photo`, `photo_thum_1`, `is_active`, `menu_main`, `menu_footer`, `postion`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'HomePage', NULL, 4, NULL, NULL, 1, 1, 1, 1, NULL, '2023-08-29 06:41:34', '2023-09-11 09:39:37'),
(2, 'OurClient', NULL, NULL, NULL, NULL, 1, 1, 1, 3, NULL, '2023-08-29 06:41:34', '2023-09-08 12:56:32'),
(3, 'LatestNews', NULL, NULL, NULL, NULL, 1, 1, 1, 4, NULL, '2023-08-29 06:41:34', '2023-09-03 09:21:59'),
(4, 'ErrorPage', NULL, NULL, NULL, NULL, 1, 0, 0, 8, NULL, '2023-08-29 06:41:34', '2023-09-03 07:25:20'),
(5, 'FaqList', NULL, NULL, NULL, NULL, 1, 1, 1, 5, NULL, '2023-08-29 06:41:34', '2023-09-03 07:44:55'),
(6, 'TermsConditions', NULL, NULL, NULL, NULL, 1, 0, 1, 6, NULL, '2023-08-29 06:41:34', '2023-09-03 07:45:03'),
(7, 'ContactUs', NULL, NULL, NULL, NULL, 1, 1, 1, 7, NULL, '2023-08-29 06:41:34', '2023-09-03 07:45:14'),
(8, 'AboutUs', NULL, NULL, NULL, NULL, 1, 1, 1, 2, NULL, '2023-08-29 06:41:34', '2023-09-03 07:44:30'),
(9, 'MainCategory', NULL, NULL, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-08 13:19:30', '2023-09-08 13:19:51'),
(10, 'Shop_HomePage', NULL, 1, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-11 12:37:49', '2023-09-11 12:37:49'),
(11, 'Shop_BestDeals', NULL, NULL, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-11 21:09:15', '2023-09-11 21:09:15'),
(12, 'Shop_WeekOffers', NULL, NULL, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-22 10:26:01', '2023-09-22 10:26:01'),
(13, 'Shop_Recently', NULL, NULL, NULL, NULL, 1, 1, 1, 0, NULL, '2023-09-22 10:26:55', '2023-09-22 10:26:55');

-- --------------------------------------------------------

--
-- Table structure for table `page_translations`
--

CREATE TABLE `page_translations` (
  `id` int(10) UNSIGNED NOT NULL,
  `page_id` int(10) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `body_h1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `breadcrumb` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `page_translations`
--

INSERT INTO `page_translations` (`id`, `page_id`, `locale`, `slug`, `name`, `g_title`, `g_des`, `body_h1`, `breadcrumb`) VALUES
(1, 1, 'ar', 'home', 'الصفحة الرئيسية', 'عتمان جروب فخر الصناعة المصرية | خدمة العملاء 01006180117', 'عتمان جروب فخر الصناعة المصرية متخصصون فى تصنيع الاشرطة ذاتية اللصق وشرائط الزينة و جميع مستلزمات التعبئة والتغليف بمصر الاسكندرية خدمة العملاء 01006180117', 'عتمان جروب', 'عتمان جروب'),
(2, 1, 'en', 'home', 'Home Page', 'Etman Group is the pride of the Egyptian industry Hotline 01006180117', 'Etman Group,the pride of the Egyptian industry, specialized in the manufacture of self-adhesive tapes, PP Ribbon and all packaging Products Hotline 01006180117', 'Etman Group', 'Etman Group'),
(3, 2, 'ar', 'عملائنا', 'عملائنا', 'عتمان جروب | قائمة بعملائنا', 'بعد اكثر من 40 عام من العمل فى السوق المصرى نتشرف بخدمة عملائنا التى تشرفنا بخدمتهم على مدار السنوات السابقة', 'عملائنا', 'عملائنا'),
(4, 2, 'en', 'our-client', 'Our Client', 'Etman Group | Our Client', 'After more than 40 years of working in the Egyptian market, we are honored to serve our customers, which we were honored to serve over the past years', 'Our Client', 'Our Client'),
(5, 3, 'ar', 'أخر-الأخبار', 'أخر الأخبار', 'عتمان جروب | أخر الاخبار | احدث العروض | الوظائف المتاحة', 'تابع اخر اخبار شركة عتمان جروب وكن دائما على علم باحداث العروض والخصومات التى نقدمه دائما والوظائف المتوفرة حاليا', 'أخر الأخبار', 'أخر الأخبار'),
(6, 3, 'en', 'latest-news', 'Latest news', 'Etman Group | Latest news | Latest Offers | Available jobs', 'Follow latest news of the Etman Group and always be aware of the latest offers and discounts that we always offer and the jobs that are currently available', 'Latest news', 'Latest news'),
(7, 4, 'ar', 'page-not-found', '404', 'عذرا !! الصفحة غير موجودة', 'عذرا !! الصفحة غير موجودة', NULL, NULL),
(8, 4, 'en', 'page-not-found', '404', 'Sorry !! Page not found', 'Sorry !! Page not found', NULL, NULL),
(9, 5, 'ar', 'الأسئلة-المتكررة', 'الأسئلة المتكررة', 'الأسئلة المتكررة | عتمان جروب | الاسكندرية 01006180117', 'تساعدك الأسئلة المتكررة على الرد لجميع الاستفسارت الخاصة بالمنتجات والعروض وطرق الشحن وطرق الدفع المتاحة لدى عتمان جروب', 'الأسئلة المتكررة', 'الأسئلة المتكررة'),
(10, 5, 'en', 'frequently-asked-questions', 'FAQ', 'Frequently Asked Questions | Etman Group | 01006180117', 'Frequently asked questions help you answer all inquiries about products, offers, shipping methods and payment methods available at Etman Group', 'Frequently Asked Questions', 'Frequently Asked Questions'),
(11, 6, 'ar', 'سياسية-الاستخدام', 'سياسية الاستخدم', 'عتمان جروب | شروط وسياسة الخصوصية', 'شروط وسياسة الخصوصية تعرفك هذه الصفحة بسياساتنا المتعلقة بجمع البيانات الشخصية واستخدامها والكشف عنها عند استخدامك للخدمة والأختيارات المرتبطة بهذه البيانات.', 'سياسية الاستخدم', NULL),
(12, 6, 'en', 'terms-conditions', 'Privacy Policy', 'Etman Group | Our Privacy Policy', 'Terms and Privacy Policy This page informs you of our policies regarding the collection, use and disclosure of personal data when you use the Service', 'Terms & Conditions', NULL),
(13, 7, 'ar', 'اتصل-بنا', 'اتصل بنا', 'عتمان جروب | اتصل بنا | الاسكندرية 01006180117', 'عتمان جروب المقر الرئيسي 14 ش خليل بك متفرع من اسماعيل صبري - أمام بنك مصر - الجمرك الاسكندرية - مصر / هاتف 01006180117', 'اتصل بنا', NULL),
(14, 7, 'en', 'contact-us', 'Contact Us', 'Etman Group | Contact Us | Alexandria 0100-6180-117', 'Etman Group Headquarters 14 Khalil Bey St., off Ismail Sabry - in front of Banque Misr - Customs, Alexandria - Egypt  Phone : 01006180117', 'Contact Us', NULL),
(15, 8, 'ar', 'من-نحن', 'من نحن', 'عتمان جروب هي شركة محلية منذ عام 1967 | الاسكندرية 01006180117', 'عتمان جروب هي شركة محلية أسسها السيد حسن عتمان منذ عام 1967. بدأت رحلة السيد عتمان نحو النجاح بفضل تطور شركته من خلال إنتاج شرائط البولي بروبلين وشرائط الزينة', 'من نحن', 'من نحن'),
(16, 8, 'en', 'about-us', 'About Us', 'Etman Group is a local company since 1967 | Alexandria 01006180117', 'Etman Group is a local company founded and operated by Mr Hassan Etman in 1967. Mr Etman’s journey to success started due to the development of his company by', 'About Us', 'About Us'),
(17, 9, 'ar', 'قائمة-المنتجات', 'قائمة المنتجات', 'قائمة المنتجات', 'قائمة المنتجات', 'قائمة المنتجات', 'قائمة المنتجات'),
(18, 9, 'en', 'category-list', 'Category List', 'Category List', 'Category List', 'Category List', 'Category List'),
(19, 10, 'ar', 'تسوق-الان-مع-عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان', 'تسوق الان مع عتمان'),
(20, 10, 'en', 'shop-now', 'Shop Now', 'Shop Now', 'Shop Now', 'Shop Now', 'Shop Now'),
(21, 11, 'ar', 'عروض-تجار-الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة'),
(22, 11, 'en', 'عروض-تجار-الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة', 'عروض تجار الجملة'),
(23, 12, 'ar', 'العروض-الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية'),
(24, 12, 'en', 'العروض-الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية', 'العروض الاسبوعية'),
(25, 13, 'ar', 'وصل-حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا'),
(26, 13, 'en', 'وصل-حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا', 'وصل حديثا');

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_id` int(11) DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `cat_id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 1, 'users_view', 'عرض', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(2, 1, 'users_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(3, 1, 'users_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(4, 1, 'users_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(5, 2, 'roles_view', 'عرض', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(6, 2, 'roles_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(7, 2, 'roles_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(8, 2, 'roles_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(9, 2, 'roles_update_permissions', 'تعديل صلاحيات المجموعة', 'Roles Update Permissions', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(10, 3, 'permissions_view', 'عرض', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(11, 3, 'permissions_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(12, 3, 'permissions_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(13, 3, 'permissions_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(14, 4, 'webPrivacy_view', 'عرض', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(15, 4, 'webPrivacy_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(16, 4, 'webPrivacy_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(17, 4, 'webPrivacy_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(18, 5, 'adminlang_view', 'عرض ملفات لغة التحكم', 'View Admin Lang', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(19, 5, 'adminlang_edit', 'تعديل ملفات لغة التحكم', 'Edit Admin Lang', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(20, 5, 'weblang_view', 'عرض ملفات لغة الموقع', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(21, 5, 'weblang_edit', 'تعديل ملفات لغة الموقع', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(22, 6, 'config_section', 'عرض الاعدادات', 'Setting View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(23, 6, 'website_config', 'اعدادات الموقع', 'Web Site Setting', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(24, 7, 'defPhoto_view', 'عرض', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(25, 7, 'defPhoto_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(26, 7, 'defPhoto_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(27, 7, 'defPhoto_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(28, 8, 'upFilter_view', 'عرض', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(29, 8, 'upFilter_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(30, 8, 'upFilter_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(31, 8, 'upFilter_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(32, 9, 'Pages_view', 'عرض', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(33, 9, 'Pages_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(34, 9, 'Pages_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(35, 9, 'Pages_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(36, 9, 'Pages_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(37, 9, 'Pages_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(38, 10, 'category_view', 'عرض', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(39, 10, 'category_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(40, 10, 'category_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(41, 10, 'category_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(42, 10, 'category_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(43, 10, 'category_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(44, 11, 'product_view', 'عرض', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(45, 11, 'product_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(46, 11, 'product_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(47, 11, 'product_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(48, 11, 'product_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(49, 12, 'OurClient_view', 'عرض', 'View', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(50, 12, 'OurClient_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(51, 12, 'OurClient_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(52, 12, 'OurClient_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:08', '2023-10-08 09:28:08'),
(53, 13, 'BlogPost_view', 'عرض', 'View', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(54, 13, 'BlogPost_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(55, 13, 'BlogPost_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(56, 13, 'BlogPost_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(57, 13, 'BlogPost_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(58, 13, 'BlogPost_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(59, 14, 'Banner_view', 'عرض', 'View', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(60, 14, 'Banner_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(61, 14, 'Banner_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(62, 14, 'Banner_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(63, 14, 'Banner_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(64, 15, 'Faq_view', 'عرض', 'View', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(65, 15, 'Faq_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(66, 15, 'Faq_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(67, 15, 'Faq_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(68, 15, 'Faq_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(69, 15, 'Faq_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(70, 16, 'shopProduct_view', 'عرض', 'View', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(71, 16, 'shopProduct_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(72, 16, 'shopProduct_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(73, 16, 'shopProduct_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(74, 16, 'shopProduct_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(75, 16, 'shopProduct_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(76, 17, 'shopCategory_view', 'عرض', 'View', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(77, 17, 'shopCategory_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(78, 17, 'shopCategory_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(79, 17, 'shopCategory_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(80, 17, 'shopCategory_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(81, 17, 'shopCategory_edit_slug', 'Edit Slug', 'Edit Slug', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(82, 18, 'ShopCustomer_view', 'عرض', 'View', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(83, 18, 'ShopCustomer_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(84, 18, 'ShopCustomer_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(85, 18, 'ShopCustomer_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(86, 18, 'ShopCustomer_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(87, 19, 'ShopOrders_view', 'عرض', 'View', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(88, 19, 'ShopOrders_add', 'اضافة', 'Add', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(89, 19, 'ShopOrders_edit', 'تعديل', 'Edit', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(90, 19, 'ShopOrders_delete', 'حذف', 'Delete', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09'),
(91, 19, 'ShopOrders_restore', 'استعادة المحذوف', 'Restore', 'web', '2023-10-08 09:28:09', '2023-10-08 09:28:09');

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sku` int(11) DEFAULT NULL,
  `price` double(8,2) DEFAULT NULL,
  `sale_price` double(8,2) DEFAULT NULL,
  `qty_left` int(11) DEFAULT NULL,
  `qty_max` int(11) DEFAULT NULL,
  `unit` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `is_archived` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `sku`, `price`, `sale_price`, `qty_left`, `qty_max`, `unit`, `photo`, `photo_thum_1`, `is_active`, `is_archived`, `created_at`, `updated_at`, `deleted_at`) VALUES
(2, NULL, 105.00, NULL, NULL, 10, NULL, '', '', 1, 0, '2023-10-08 08:24:40', '2023-10-08 08:27:52', NULL),
(3, NULL, 400.00, NULL, NULL, 10, NULL, NULL, NULL, 1, 0, '2023-10-08 09:08:41', '2023-10-08 09:08:41', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `product_photos`
--

CREATE TABLE `product_photos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_extension` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `file_h` int(11) DEFAULT NULL,
  `file_w` int(11) DEFAULT NULL,
  `position` int(11) NOT NULL DEFAULT 0,
  `is_default` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product_translations`
--

CREATE TABLE `product_translations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `locale` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `des` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_des` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_translations`
--

INSERT INTO `product_translations` (`id`, `product_id`, `locale`, `slug`, `name`, `des`, `g_title`, `g_des`) VALUES
(2, 2, 'ar', 'dsfdsdsfdsf', 'هانى', NULL, NULL, NULL),
(3, 3, 'ar', 'الطول', 'الطول', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_ar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `name_ar`, `name_en`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'ادمن كامل الصلاحيات', 'Full Admin Permission ', 'web', '2023-10-06 11:39:21', '2023-10-06 11:39:21'),
(2, 'WebEditor', 'محرر  الموقع', 'محرر  الموقع', 'web', '2023-10-06 11:39:22', '2023-10-06 11:41:04'),
(3, 'ShopEditor', 'محرر المتجر', 'محرر المتجر', 'web', '2023-10-06 11:41:34', '2023-10-06 11:41:34'),
(4, 'Orders', 'ادارة الطلبات', 'ادارة الطلبات', 'web', '2023-10-06 11:42:04', '2023-10-06 11:42:04'),
(5, 'WebConfig', 'ادارة اعدادت الموقع', 'ادارة اعدادت الموقع', 'web', '2023-10-06 11:43:12', '2023-10-06 11:43:12'),
(6, 'UsersEditor', 'ادارة المستخدمين', 'ادارة المستخدمين', 'web', '2023-10-06 11:44:17', '2023-10-06 11:44:17'),
(7, 'CustomerEditor', 'ادارة العملاء', 'ادارة العملاء', 'web', '2023-10-06 11:45:12', '2023-10-06 11:45:12');

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

CREATE TABLE `role_has_permissions` (
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(14, 2),
(15, 1),
(15, 2),
(16, 1),
(16, 2),
(17, 1),
(18, 1),
(19, 1),
(20, 1),
(20, 2),
(21, 1),
(21, 2),
(22, 1),
(22, 2),
(23, 1),
(24, 1),
(24, 2),
(25, 1),
(26, 1),
(26, 2),
(27, 1),
(28, 1),
(28, 2),
(29, 1),
(30, 1),
(31, 1),
(32, 1),
(32, 2),
(33, 1),
(34, 1),
(34, 2),
(35, 1),
(36, 1),
(37, 1),
(38, 1),
(38, 2),
(39, 1),
(39, 2),
(40, 1),
(40, 2),
(40, 3),
(41, 1),
(42, 1),
(43, 1),
(44, 1),
(44, 2),
(45, 1),
(45, 2),
(46, 1),
(46, 2),
(47, 1),
(48, 1),
(49, 1),
(49, 2),
(50, 1),
(50, 2),
(51, 1),
(51, 2),
(52, 1),
(52, 2),
(53, 1),
(53, 2),
(54, 1),
(54, 2),
(55, 1),
(55, 2),
(56, 1),
(56, 2),
(57, 1),
(58, 1),
(59, 1),
(59, 2),
(60, 1),
(60, 2),
(61, 1),
(61, 2),
(62, 1),
(62, 2),
(63, 1),
(64, 1),
(64, 2),
(65, 1),
(65, 2),
(66, 1),
(66, 2),
(67, 1),
(67, 2),
(68, 1),
(69, 1),
(70, 1),
(70, 3),
(71, 1),
(71, 3),
(72, 1),
(72, 3),
(73, 1),
(74, 1),
(75, 1),
(76, 1),
(76, 3),
(77, 1),
(77, 3),
(78, 1),
(78, 3),
(79, 1),
(80, 1),
(81, 1),
(82, 1),
(82, 7),
(83, 1),
(83, 7),
(84, 1),
(84, 7),
(85, 1),
(86, 1),
(87, 1),
(87, 4),
(88, 1),
(88, 4),
(89, 1),
(89, 4),
(90, 1),
(91, 1);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

CREATE TABLE `shopping_cart` (
  `identifier` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instance` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `shopping_orders`
--

CREATE TABLE `shopping_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `address_id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` datetime NOT NULL,
  `invoice_number` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `total` double(8,2) NOT NULL DEFAULT 0.00,
  `units` int(11) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shopping_orders`
--

INSERT INTO `shopping_orders` (`id`, `customer_id`, `address_id`, `uuid`, `order_date`, `invoice_number`, `status`, `total`, `units`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, '49eb3c14-e675-469f-b455-d788eb746e1a', '2023-09-30 22:40:37', NULL, 2, 1700.00, 5, NULL, '2023-09-30 19:40:37', '2023-10-05 11:20:26'),
(2, 1, 2, '08eb13c5-1db8-493c-9229-acf1f1357e46', '2023-09-30 22:55:06', NULL, 4, 3400.00, 5, NULL, '2023-09-30 19:55:06', '2023-10-05 11:20:58'),
(3, 1, 3, 'a26da499-e94b-4c8e-acbb-9b31644a59e2', '2023-09-30 23:05:40', NULL, 4, 2856.00, 2, NULL, '2023-09-30 20:05:40', '2023-10-05 11:21:13'),
(4, 1, 4, '4df5ec79-6c41-4148-b45e-411c490f2f9e', '2023-09-30 23:06:27', NULL, 1, 2984.00, 9, NULL, '2023-09-30 20:06:27', '2023-09-30 20:06:27'),
(5, 1, 5, '88eb7097-d2a0-49f0-b62d-bfe4fd45dad1', '2023-10-01 01:18:37', NULL, 1, 2052.00, 3, NULL, '2023-09-30 22:18:37', '2023-09-30 22:18:37'),
(6, 1, 6, 'c005f00d-e921-44c2-9b23-4d5cb2d8a704', '2023-10-01 01:37:51', '5454646546', 3, 2400.00, 5, NULL, '2023-09-30 22:37:51', '2023-10-05 11:27:54'),
(7, 1, 7, 'bf3b5a19-1663-4943-b545-7a82ac25ab6c', '2023-10-05 11:21:16', '151515', 3, 8748.00, 17, NULL, '2023-10-05 08:21:16', '2023-10-05 11:23:18'),
(8, 2, 8, 'c9f42cbe-2670-4134-9327-a05ff8035f69', '2023-10-05 19:56:47', NULL, 1, 1900.00, 3, NULL, '2023-10-05 16:56:47', '2023-10-05 16:56:47'),
(9, 2, 9, 'cea1753f-5997-4a9e-b9a8-16a9a85a3a54', '2023-10-05 19:57:52', NULL, 2, 1650.00, 5, NULL, '2023-10-05 16:57:52', '2023-10-06 19:36:17'),
(10, 2, 10, '1220cb48-7b2f-4083-9f99-dca8b99f9b26', '2023-10-05 19:59:11', NULL, 2, 5619.00, 12, NULL, '2023-10-05 16:59:11', '2023-10-06 16:43:41'),
(11, 1, 11, '91b3ffed-37ab-4fbd-8d23-b728f689e813', '2023-10-05 20:00:36', NULL, 2, 150.00, 1, NULL, '2023-10-05 17:00:36', '2023-10-06 16:43:34'),
(12, 3, 12, '824e1a43-93ae-466a-af5c-d3fc4f12f5fc', '2023-10-05 20:01:58', '5454646546', 3, 950.00, 3, NULL, '2023-10-05 17:01:58', '2023-10-06 19:35:51');

-- --------------------------------------------------------

--
-- Table structure for table `shopping_order_addresses`
--

CREATE TABLE `shopping_order_addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_option` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shopping_order_addresses`
--

INSERT INTO `shopping_order_addresses` (`id`, `name`, `city`, `address`, `recipient_name`, `phone`, `phone_option`, `notes`) VALUES
(1, 'المنزل', 'الاسكندرية', '598 طريق الحرية لوران الاسكندرية \r\nبرج الجوهرة \r\nالدرو الثامن', 'زين احمد عتمان', '01222279182', NULL, NULL),
(2, 'بحرى الجمرك', 'الاسكندرية', '14 ش خليل بك متفرع من شارع\r\nاسماعيل صبري - الجمرك\r\nالاسكندرية - مصر', 'احمد عتمان', '01223129660', '4867311', NULL),
(3, 'المنزل', 'الاسكندرية', '598 طريق الحرية لوران الاسكندرية \r\nبرج الجوهرة \r\nالدرو الثامن', 'زين احمد عتمان', '01222279182', NULL, NULL),
(4, 'المنزل', 'الاسكندرية', '598 طريق الحرية لوران الاسكندرية \r\nبرج الجوهرة \r\nالدرو الثامن', 'زين احمد عتمان', '01222279182', NULL, NULL),
(5, 'المنزل', 'الاسكندرية', '598 طريق الحرية لوران الاسكندرية \r\nبرج الجوهرة \r\nالدرو الثامن', 'زين احمد عتمان', '01222279182', NULL, NULL),
(6, 'المنزل', 'الاسكندرية', '598 طريق الحرية لوران الاسكندرية \r\nبرج الجوهرة \r\nالدرو الثامن', 'زين احمد عتمان', '01222279182', NULL, NULL),
(7, 'المنزل', 'الاسكندرية', '598 طريق الحرية لوران الاسكندرية \r\nبرج الجوهرة \r\nالدرو الثامن', 'زين احمد عتمان', '01222279182', NULL, NULL),
(8, 'العنوان الافتراضى', 'الاسكندرية', '29 شارع الشيخ محمد عبده \r\nالجمرك - خلف جيلاتى عزة', 'هانى درويش', '01221563252', NULL, NULL),
(9, 'العنوان الافتراضى', 'الاسكندرية', '29 شارع الشيخ محمد عبده \r\nالجمرك - خلف جيلاتى عزة', 'هانى درويش', '01221563252', NULL, 'برجاء التاكيد على توفر الاصناف'),
(10, 'العنوان الافتراضى', 'الاسكندرية', '29 شارع الشيخ محمد عبده \r\nالجمرك - خلف جيلاتى عزة', 'هانى درويش', '01221563252', NULL, NULL),
(11, 'المنزل', 'الاسكندرية', '598 طريق الحرية لوران الاسكندرية \r\nبرج الجوهرة \r\nالدرو الثامن', 'زين احمد عتمان', '01222279182', NULL, NULL),
(12, 'العنوان الافتراضى', 'الاسكندرية', '14 ش خليل بك متفرع من شارع\r\nاسماعيل صبري - الجمرك\r\nالاسكندرية - مصر', 'محمد أنور', '01117777093', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_order_logs`
--

CREATE TABLE `shopping_order_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `add_date` datetime NOT NULL,
  `notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shopping_order_logs`
--

INSERT INTO `shopping_order_logs` (`id`, `order_id`, `user_id`, `add_date`, `notes`) VALUES
(1, 1, 1, '2023-10-05 14:20:26', NULL),
(2, 7, 1, '2023-10-05 14:20:36', NULL),
(3, 2, 1, '2023-10-05 14:20:58', 'لا يوجد مخزون'),
(4, 3, 1, '2023-10-05 14:21:13', 'رصيد العميل لا يسمح'),
(5, 6, 1, '2023-10-05 14:21:37', NULL),
(6, 7, 1, '2023-10-05 14:23:18', NULL),
(7, 6, 1, '2023-10-05 14:27:54', NULL),
(8, 12, 4, '2023-10-06 19:43:25', NULL),
(9, 11, 4, '2023-10-06 19:43:34', NULL),
(10, 10, 4, '2023-10-06 19:43:41', NULL),
(11, 12, 1, '2023-10-06 22:35:51', NULL),
(12, 9, 1, '2023-10-06 22:36:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `shopping_order_products`
--

CREATE TABLE `shopping_order_products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `order_id` bigint(20) UNSIGNED NOT NULL,
  `product_ref` int(11) NOT NULL,
  `sku` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` double(8,2) NOT NULL,
  `sale_price` double(8,2) DEFAULT NULL,
  `qty` double(8,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `shopping_order_products`
--

INSERT INTO `shopping_order_products` (`id`, `order_id`, `product_ref`, `sku`, `name`, `price`, `sale_price`, `qty`) VALUES
(1, 1, 56, '43744223', 'مسدس شمع بسلك كهرباء من يوني-تي موديل EH430', 500.00, NULL, 1.00),
(2, 1, 57, '53492624', 'مسدس شمع ST-03 20W، حجم صغير - ازرق', 200.00, 175.00, 1.00),
(3, 1, 58, '35945023', 'مسدس شمع برو جلو من ستانلي GR100', 525.00, 450.00, 1.00),
(4, 1, 59, '28262230', 'مسدس شمع من عتمان جروب، متعدد الألوان', 300.00, 225.00, 1.00),
(5, 1, 60, '23307506', 'مسدس غراء احترافي 220 وات من توتال TT301116', 400.00, 350.00, 1.00),
(6, 2, 56, '43744223', 'مسدس شمع بسلك كهرباء من يوني-تي موديل EH430', 500.00, NULL, 2.00),
(7, 2, 57, '53492624', 'مسدس شمع ST-03 20W، حجم صغير - ازرق', 200.00, 175.00, 2.00),
(8, 2, 58, '35945023', 'مسدس شمع برو جلو من ستانلي GR100', 525.00, 450.00, 2.00),
(9, 2, 59, '28262230', 'مسدس شمع من عتمان جروب، متعدد الألوان', 300.00, 225.00, 2.00),
(10, 2, 60, '23307506', 'مسدس غراء احترافي 220 وات من توتال TT301116', 400.00, 350.00, 2.00),
(11, 3, 15, '27112927', 'الومنيوم فويل مستر فويل 50 جرام', 528.00, 461.00, 4.00),
(12, 3, 53, '60959804', 'الومنيوم فويل كينك', 308.00, 253.00, 4.00),
(13, 4, 13, '99892834', 'قابل للكسر', 549.00, 449.00, 1.00),
(14, 4, 7, '73571010', 'ذا بيست', 513.00, 450.00, 1.00),
(15, 4, 9, '77297683', 'جرين ماسك تيب', 569.00, 476.00, 1.00),
(16, 4, 10, '58919463', 'اى تى ماسك تيب', 450.00, 370.00, 1.00),
(17, 4, 12, '93203908', 'فريش', 407.00, 314.00, 1.00),
(18, 4, 1, '12590966', 'نار تيب', 200.00, 100.00, 1.00),
(19, 4, 2, '91103331', 'ذا بيست تيب', 500.00, NULL, 1.00),
(20, 4, 3, '42512152', 'كريستال تيب', 243.00, 150.00, 1.00),
(21, 4, 4, '73625246', 'جرين تيب', 236.00, 175.00, 1.00),
(22, 5, 50, '93276582', 'مستر فويل للارجيلة', 491.00, 394.00, 2.00),
(23, 5, 51, '25501127', 'غطاء بوتاجز مستر فويل', 338.00, 282.00, 1.00),
(24, 5, 52, '63421658', 'غطاء بوتاجز مستر فويل', 551.00, 491.00, 2.00),
(25, 6, 56, '43744223', 'مسدس شمع بسلك كهرباء من يوني-تي موديل EH430', 500.00, NULL, 1.00),
(26, 6, 57, '53492624', 'مسدس شمع ST-03 20W، حجم صغير - ازرق', 200.00, 175.00, 1.00),
(27, 6, 58, '35945023', 'مسدس شمع برو جلو من ستانلي GR100', 525.00, 450.00, 1.00),
(28, 6, 59, '28262230', 'مسدس شمع من عتمان جروب، متعدد الألوان', 300.00, 225.00, 1.00),
(29, 6, 60, '23307506', 'مسدس غراء احترافي 220 وات من توتال TT301116', 400.00, 350.00, 3.00),
(30, 7, 60, '23307506', 'مسدس غراء احترافي 220 وات من توتال TT301116', 400.00, 350.00, 2.00),
(31, 7, 59, '28262230', 'مسدس شمع من عتمان جروب، متعدد الألوان', 150.00, NULL, 2.00),
(32, 7, 58, '35945023', 'مسدس شمع برو جلو من ستانلي GR100', 525.00, 450.00, 3.00),
(33, 7, 57, '53492624', 'مسدس شمع ST-03 20W، حجم صغير - ازرق', 200.00, NULL, 3.00),
(34, 7, 56, '43744223', 'مسدس شمع بسلك كهرباء من يوني-تي موديل EH430', 500.00, NULL, 2.00),
(35, 7, 1, '12590966', 'نار تيب', 200.00, 100.00, 2.00),
(36, 7, 2, '91103331', 'ذا بيست تيب', 500.00, NULL, 2.00),
(37, 7, 3, '42512152', 'كريستال تيب', 243.00, 150.00, 2.00),
(38, 7, 4, '73625246', 'جرين تيب', 236.00, 175.00, 2.00),
(39, 7, 16, '64039482', 'شرائط الزينة ½ سم', 259.00, 196.00, 1.00),
(40, 7, 15, '27112927', 'الومنيوم فويل مستر فويل 50 جرام', 528.00, 461.00, 1.00),
(41, 7, 14, '46035437', 'شرائط العزل الكهربائي ET', 299.00, 232.00, 1.00),
(42, 7, 13, '99892834', 'قابل للكسر', 549.00, 449.00, 1.00),
(43, 7, 7, '73571010', 'ذا بيست', 513.00, 450.00, 1.00),
(44, 7, 9, '77297683', 'جرين ماسك تيب', 569.00, 476.00, 1.00),
(45, 7, 10, '58919463', 'اى تى ماسك تيب', 450.00, 370.00, 1.00),
(46, 7, 12, '93203908', 'فريش', 407.00, 314.00, 1.00),
(47, 8, 60, '23307506', 'مسدس غراء احترافي 220 وات من توتال TT301116', 400.00, 350.00, 2.00),
(48, 8, 59, '28262230', 'مسدس شمع من عتمان جروب، متعدد الألوان', 150.00, NULL, 2.00),
(49, 8, 58, '35945023', 'مسدس شمع برو جلو من ستانلي GR100', 525.00, 450.00, 2.00),
(50, 9, 57, '53492624', 'مسدس شمع ST-03 20W، حجم صغير - ازرق', 200.00, NULL, 1.00),
(51, 9, 56, '43744223', 'مسدس شمع بسلك كهرباء من يوني-تي موديل EH430', 500.00, NULL, 1.00),
(52, 9, 59, '28262230', 'مسدس شمع من عتمان جروب، متعدد الألوان', 150.00, NULL, 1.00),
(53, 9, 60, '23307506', 'مسدس غراء احترافي 220 وات من توتال TT301116', 400.00, 350.00, 1.00),
(54, 9, 58, '35945023', 'مسدس شمع برو جلو من ستانلي GR100', 525.00, 450.00, 1.00),
(55, 10, 1, '12590966', 'نار تيب', 200.00, 100.00, 2.00),
(56, 10, 2, '91103331', 'ذا بيست تيب', 500.00, NULL, 2.00),
(57, 10, 3, '42512152', 'كريستال تيب', 243.00, 150.00, 2.00),
(58, 10, 4, '73625246', 'جرين تيب', 236.00, 175.00, 3.00),
(59, 10, 7, '73571010', 'ذا بيست', 513.00, 450.00, 2.00),
(60, 10, 9, '77297683', 'جرين ماسك تيب', 569.00, 476.00, 1.00),
(61, 10, 10, '58919463', 'اى تى ماسك تيب', 450.00, 370.00, 1.00),
(62, 10, 12, '93203908', 'فريش', 407.00, 314.00, 1.00),
(63, 10, 13, '99892834', 'قابل للكسر', 549.00, 449.00, 1.00),
(64, 10, 14, '46035437', 'شرائط العزل الكهربائي ET', 299.00, 232.00, 1.00),
(65, 10, 15, '27112927', 'الومنيوم فويل مستر فويل 50 جرام', 528.00, 461.00, 1.00),
(66, 10, 16, '64039482', 'شرائط الزينة ½ سم', 259.00, 196.00, 2.00),
(67, 11, 59, '28262230', 'مسدس شمع من عتمان جروب، متعدد الألوان', 150.00, NULL, 1.00),
(68, 12, 60, '23307506', 'مسدس غراء احترافي 220 وات من توتال TT301116', 400.00, 350.00, 1.00),
(69, 12, 59, '28262230', 'مسدس شمع من عتمان جروب، متعدد الألوان', 150.00, NULL, 1.00),
(70, 12, 58, '35945023', 'مسدس شمع برو جلو من ستانلي GR100', 525.00, 450.00, 1.00);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `roles_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `phone`, `photo`, `photo_thum_1`, `roles_name`, `status`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Hany Darwish ', 'hany.freestyle4u@gmail.com', NULL, NULL, NULL, '[\"admin\"]', 1, NULL, '$2y$10$EStiO4vL.VXmDbSByRkMDuF5w5xMXfcTYl7CmXaLfFaM1HWpyFIjq', NULL, '2023-10-06 11:39:21', '2023-10-06 11:39:21'),
(2, 'ادارة الموقع', 'user1@etman-group.com', NULL, NULL, NULL, '[\"WebEditor\"]', 1, NULL, '$2y$10$h1u/qiUoz3ugsakqugSB4uTkFFjVHDTul/kuZFXc9eQq3xsJIiiW6', NULL, '2023-10-06 11:39:22', '2023-10-06 12:00:51'),
(3, 'ادارة المتجر', 'user2@etman-group.com', NULL, NULL, NULL, '[\"ShopEditor\",\"Orders\",\"CustomerEditor\"]', 1, NULL, '$2y$10$mHVaciHskWCa88oK6nPgR.FdAw/nCuYu8uO9KGmwWgntvM4.YfwL6', NULL, '2023-10-06 11:39:22', '2023-10-06 14:08:20'),
(4, 'ادارة الطلبات', 'user3@etman-group.com', NULL, NULL, NULL, '[\"Orders\",\"CustomerEditor\"]', 1, NULL, '$2y$10$0kN0y42eGh9NmczfzKy40OtmzNSA8xwnTYz3IVg1JJHy6jGfaVkxO', NULL, '2023-10-06 11:58:52', '2023-10-06 14:07:48');

-- --------------------------------------------------------

--
-- Table structure for table `users_customers`
--

CREATE TABLE `users_customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `whatsapp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `land_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 1,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `photo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `photo_thum_1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password_temp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_customers`
--

INSERT INTO `users_customers` (`id`, `name`, `company_name`, `email`, `phone`, `whatsapp`, `land_phone`, `city_id`, `status`, `is_active`, `photo`, `photo_thum_1`, `email_verified_at`, `password`, `password_temp`, `last_login`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'احمد عتمان', 'عتمان جروب', 'etmano@hotmail.com', '01223129660', '01223129660', '4867311', 3, 1, 1, NULL, NULL, NULL, '$2y$10$sLfSr0tHo64x7IZKKpngeeaFOx21kJPqxZSRKRe6xKPD1y5kKGb7.', NULL, '2023-10-05 22:02:19', NULL, '2023-09-29 12:06:43', '2023-10-05 19:02:19', NULL),
(2, 'هانى درويش', 'فري ستايل', NULL, '01221563252', '01221563252', NULL, 3, 1, 1, NULL, NULL, NULL, '$2y$10$MHBY2M/C3svXIUBJLh2mQOXTisysi0KtukM8CTPKORjEzDq5gUDWy', '01221563252@5604', NULL, NULL, '2023-10-05 04:21:30', '2023-10-05 16:21:07', NULL),
(3, 'محمد أنور', 'عتمان جروب', NULL, '01117777093', NULL, NULL, 3, 1, 1, NULL, NULL, NULL, '$2y$10$Iz3a3.vJliK..EAPlQeY/OIVLXTwC21EhBbG03SF4Z3vmO5MoD2Ou', '01117777093@6067', NULL, NULL, '2023-10-05 04:22:44', '2023-10-05 17:01:33', NULL),
(4, 'أحمد جمعة', 'عتمان جروب', NULL, '01096693772', NULL, NULL, 3, 1, 1, NULL, NULL, NULL, '$2y$10$vSYuKgMW2KaDbGrS4bxcIu1sY8dyZddJo4aDENOPk2g2S5d73o44i', '01096693772@6481', NULL, NULL, '2023-10-05 04:24:01', '2023-10-05 04:24:01', NULL),
(5, 'ايمن بكر', 'عتمان جروب', NULL, '01032977744', NULL, NULL, 3, 1, 1, NULL, NULL, NULL, '$2y$10$/xOxaTH0s3BW7ZoITRXWUOso8/632JWOB7eI0koTxklSSTJa5s/4q', '01032977744@6528', NULL, NULL, '2023-10-05 04:25:10', '2023-10-05 04:25:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users_customers_addresses`
--

CREATE TABLE `users_customers_addresses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` bigint(20) UNSIGNED NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipient_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone_option` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users_customers_addresses`
--

INSERT INTO `users_customers_addresses` (`id`, `uuid`, `customer_id`, `name`, `city_id`, `address`, `recipient_name`, `phone`, `phone_option`, `is_default`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, '6907412f-6b65-43a1-a358-c8a53116b9b5', 1, 'بحرى الجمرك', 3, '14 ش خليل بك متفرع من شارع\r\nاسماعيل صبري - الجمرك\r\nالاسكندرية - مصر', 'احمد عتمان', '01223129660', '4867311', 0, NULL, '2023-09-29 16:19:38', '2023-09-29 18:07:50'),
(2, 'eee698b6-3c8b-4ca4-9194-86b9df96bed8', 1, 'المنزل', 3, '598 طريق الحرية لوران الاسكندرية \r\nبرج الجوهرة \r\nالدرو الثامن', 'زين احمد عتمان', '01222279182', NULL, 1, NULL, '2023-09-29 17:11:13', '2023-09-29 18:07:50'),
(3, '72c9671b-ea2e-4a5b-8912-1cff8e8ab9c0', 1, 'سابا باشا', 3, '336 طريق الجيش امام نادي التجاريين\r\nعمارات رويال بلازا - سابا باشا\r\nالاسكندرية - مصر', 'احمد عتمان', '01223129660', '5868324', 0, NULL, '2023-09-29 17:12:37', '2023-09-29 18:07:50'),
(4, '797a3e9a-257d-4af7-9184-3a20a1099bab', 2, 'العنوان الافتراضى', 3, '29 شارع الشيخ محمد عبده \r\nالجمرك - خلف جيلاتى عزة', 'هانى درويش', '01221563252', NULL, 1, NULL, '2023-10-05 04:21:30', '2023-10-05 04:21:30'),
(5, 'faa7ee79-a6a5-40ee-8b75-a619e33f1216', 3, 'العنوان الافتراضى', 3, '14 ش خليل بك متفرع من شارع\r\nاسماعيل صبري - الجمرك\r\nالاسكندرية - مصر', 'محمد أنور', '01117777093', NULL, 1, NULL, '2023-10-05 04:22:44', '2023-10-05 04:22:44'),
(6, 'e452d9a3-ceee-4df5-9819-2e39061d3130', 4, 'العنوان الافتراضى', 3, '14 ش خليل بك متفرع من شارع\r\nاسماعيل صبري - الجمرك\r\nالاسكندرية - مصر', 'أحمد جمعة', '01096693772', NULL, 1, NULL, '2023-10-05 04:24:01', '2023-10-05 04:24:01'),
(7, '1dce971a-b446-45e0-8560-b2c4c0b05b96', 5, 'العنوان الافتراضى', 3, '14 ش خليل بك متفرع من شارع\r\nاسماعيل صبري - الجمرك\r\nالاسكندرية - مصر', 'ايمن بكر', '01032977744', NULL, 1, NULL, '2023-10-05 04:25:10', '2023-10-05 04:25:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_parent_id_foreign` (`parent_id`);

--
-- Indexes for table `category_product`
--
ALTER TABLE `category_product`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_product_category_id_foreign` (`category_id`),
  ADD KEY `category_product_product_id_foreign` (`product_id`);

--
-- Indexes for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `category_translations_category_id_locale_unique` (`category_id`,`locale`),
  ADD UNIQUE KEY `category_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `category_translations_locale_index` (`locale`);

--
-- Indexes for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_settings`
--
ALTER TABLE `config_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_setting_translations_setting_id_locale_unique` (`setting_id`,`locale`),
  ADD KEY `config_setting_translations_locale_index` (`locale`);

--
-- Indexes for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `config_upload_filter_sizes_filter_id_foreign` (`filter_id`);

--
-- Indexes for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `config_web_privacy_translations_privacy_id_locale_unique` (`privacy_id`,`locale`),
  ADD KEY `config_web_privacy_translations_locale_index` (`locale`);

--
-- Indexes for table `contact_us_forms`
--
ALTER TABLE `contact_us_forms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_cities`
--
ALTER TABLE `data_cities`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `data_cities_name_unique` (`name`),
  ADD UNIQUE KEY `data_cities_name_en_unique` (`name_en`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  ADD KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  ADD KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`);

--
-- Indexes for table `news_letters`
--
ALTER TABLE `news_letters`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `news_letters_email_unique` (`email`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `pages_cat_id_unique` (`cat_id`);

--
-- Indexes for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `page_translations_page_id_locale_unique` (`page_id`,`locale`),
  ADD UNIQUE KEY `page_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `page_translations_locale_index` (`locale`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_photos`
--
ALTER TABLE `product_photos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_photos_product_id_foreign` (`product_id`);

--
-- Indexes for table `product_translations`
--
ALTER TABLE `product_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `product_translations_product_id_locale_unique` (`product_id`,`locale`),
  ADD UNIQUE KEY `product_translations_locale_slug_unique` (`locale`,`slug`),
  ADD KEY `product_translations_locale_index` (`locale`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`);

--
-- Indexes for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD PRIMARY KEY (`permission_id`,`role_id`),
  ADD KEY `role_has_permissions_role_id_foreign` (`role_id`);

--
-- Indexes for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD PRIMARY KEY (`identifier`,`instance`);

--
-- Indexes for table `shopping_orders`
--
ALTER TABLE `shopping_orders`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `shopping_orders_uuid_unique` (`uuid`),
  ADD KEY `shopping_orders_customer_id_foreign` (`customer_id`),
  ADD KEY `shopping_orders_address_id_foreign` (`address_id`);

--
-- Indexes for table `shopping_order_addresses`
--
ALTER TABLE `shopping_order_addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopping_order_logs`
--
ALTER TABLE `shopping_order_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shopping_order_logs_order_id_foreign` (`order_id`);

--
-- Indexes for table `shopping_order_products`
--
ALTER TABLE `shopping_order_products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `shopping_order_products_order_id_foreign` (`order_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `users_customers`
--
ALTER TABLE `users_customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_customers_phone_unique` (`phone`),
  ADD UNIQUE KEY `users_customers_email_unique` (`email`);

--
-- Indexes for table `users_customers_addresses`
--
ALTER TABLE `users_customers_addresses`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_customers_addresses_uuid_unique` (`uuid`),
  ADD KEY `users_customers_addresses_customer_id_foreign` (`customer_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `category_product`
--
ALTER TABLE `category_product`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `category_translations`
--
ALTER TABLE `category_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `config_def_photos`
--
ALTER TABLE `config_def_photos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `config_settings`
--
ALTER TABLE `config_settings`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `config_upload_filters`
--
ALTER TABLE `config_upload_filters`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `config_web_privacies`
--
ALTER TABLE `config_web_privacies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `contact_us_forms`
--
ALTER TABLE `contact_us_forms`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `data_cities`
--
ALTER TABLE `data_cities`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=166;

--
-- AUTO_INCREMENT for table `news_letters`
--
ALTER TABLE `news_letters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `page_translations`
--
ALTER TABLE `page_translations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_photos`
--
ALTER TABLE `product_photos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `product_translations`
--
ALTER TABLE `product_translations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `shopping_orders`
--
ALTER TABLE `shopping_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `shopping_order_addresses`
--
ALTER TABLE `shopping_order_addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `shopping_order_logs`
--
ALTER TABLE `shopping_order_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `shopping_order_products`
--
ALTER TABLE `shopping_order_products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users_customers`
--
ALTER TABLE `users_customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users_customers_addresses`
--
ALTER TABLE `users_customers_addresses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `categories`
--
ALTER TABLE `categories`
  ADD CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `category_product`
--
ALTER TABLE `category_product`
  ADD CONSTRAINT `category_product_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `category_product_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `category_translations`
--
ALTER TABLE `category_translations`
  ADD CONSTRAINT `category_translations_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_setting_translations`
--
ALTER TABLE `config_setting_translations`
  ADD CONSTRAINT `config_setting_translations_setting_id_foreign` FOREIGN KEY (`setting_id`) REFERENCES `config_settings` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_upload_filter_sizes`
--
ALTER TABLE `config_upload_filter_sizes`
  ADD CONSTRAINT `config_upload_filter_sizes_filter_id_foreign` FOREIGN KEY (`filter_id`) REFERENCES `config_upload_filters` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `config_web_privacy_translations`
--
ALTER TABLE `config_web_privacy_translations`
  ADD CONSTRAINT `config_web_privacy_translations_privacy_id_foreign` FOREIGN KEY (`privacy_id`) REFERENCES `config_web_privacies` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_permissions`
--
ALTER TABLE `model_has_permissions`
  ADD CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `model_has_roles`
--
ALTER TABLE `model_has_roles`
  ADD CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `page_translations`
--
ALTER TABLE `page_translations`
  ADD CONSTRAINT `page_translations_page_id_foreign` FOREIGN KEY (`page_id`) REFERENCES `pages` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_photos`
--
ALTER TABLE `product_photos`
  ADD CONSTRAINT `product_photos_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `product_translations`
--
ALTER TABLE `product_translations`
  ADD CONSTRAINT `product_translations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `role_has_permissions`
--
ALTER TABLE `role_has_permissions`
  ADD CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `shopping_orders`
--
ALTER TABLE `shopping_orders`
  ADD CONSTRAINT `shopping_orders_address_id_foreign` FOREIGN KEY (`address_id`) REFERENCES `shopping_order_addresses` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `shopping_orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users_customers` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `shopping_order_logs`
--
ALTER TABLE `shopping_order_logs`
  ADD CONSTRAINT `shopping_order_logs_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `shopping_orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `shopping_order_products`
--
ALTER TABLE `shopping_order_products`
  ADD CONSTRAINT `shopping_order_products_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `shopping_orders` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `users_customers_addresses`
--
ALTER TABLE `users_customers_addresses`
  ADD CONSTRAINT `users_customers_addresses_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users_customers` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
